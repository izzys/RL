disp('Installing RL toolbox ...')

addpath @ReinforcementLearning
addpath Abstract
addpath Methods
addpath Models
savepath 

disp('Done! type RLgui in comand window to start toolbox.');